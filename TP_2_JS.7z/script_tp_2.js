//Exercice
var n;
n = prompt("veuillez entrer un nombre n =");
document.write(n)

//Exercice 1
var result;
var a;
var b;
a=5;
b=8;
result=(a+b);
alert(result);

//Exercice 2
let math = 8;
let francais = 15;
let hg = 17;
let moy = Number(math+francais+hg)/3;
alert("La moyenne de " + math +" + " + francais+ " + " + hg+" " +"est de  : " + moy);

//Exercice 3

let budget = Number(prompt("veuillez entrer votre budget ="));
let achats = Number(prompt("veuillez entrer votre achat ="));

if (achats<budget){
    alert("Votre budget est suffisant pour votre achat");
}
else{
    alert("Paiement refusé");
}zee




